<?php
/**
 * Main template file.
 *
 * Required by WordPress so the theme is not marked as broken.
 */

if (!defined('ABSPATH')) {
    exit;
}

// If a static front page is set, WordPress will use front-page.php automatically.
get_header();
?>

<main id="primary" class="site-main">
    <?php
    if (have_posts()) :
        while (have_posts()) :
            the_post();
            get_template_part('template-parts/content', get_post_type());
        endwhile;

        the_posts_navigation();
    else :
        get_template_part('template-parts/content', 'none');
    endif;
    ?>
</main>

<?php
get_footer();

